# Databricks notebook source
pip install pytest

# COMMAND ----------

import pytest

# COMMAND ----------

dbutils.widgets.text("schema_name", "")
dbutils.widgets.text("table_name", "")
dbutils.widgets.text("expected_columns", "")  # Format: col1:datatype,col2:datatype

# COMMAND ----------

schema_name = dbutils.widgets.get("schema_name")
table_name = dbutils.widgets.get("table_name")
expected_columns_raw = dbutils.widgets.get("expected_columns")

# COMMAND ----------

# Accept input parameters
dbutils.widgets.text("schema_name", "enriched")
dbutils.widgets.text("table_name", "crm_phonecall")
dbutils.widgets.text("expected_columns", "statecodeName:number(null)")  # Format: col1:datatype(length),col2:datatype(length)

# COMMAND ----------

full_table_name = f"{schema_name}.{table_name}"
print(f"Full table name: {full_table_name}")

# COMMAND ----------

expected_columns = {}
for item in expected_columns_raw.split(","):
    if ":" in item:
        colname, datatype = item.strip().split(":")
        expected_columns[colname.strip()] = datatype.strip().lower()
    else:
        raise ValueError(f"Invalid expected column format: '{item}'. Expected 'column:datatype'.")

print(f"Testing Table: {full_table_name}")
print(f"Expected Columns and Datatypes: {expected_columns}")

# COMMAND ----------

try:
    df = spark.table(full_table_name)
    current_schema = {field.name: field.dataType.simpleString().lower() for field in df.schema.fields}
    # print(f"Current Schema: {current_schema}")
except Exception as e:
    raise Exception(f"Error reading table {full_table_name}: {str(e)}")

# COMMAND ----------

def test_expected_columns_exist_and_validate_types():
    missing_columns = []
    type_mismatch_columns = []

    for col, expected_type in expected_columns.items():
        if col not in current_schema:
            missing_columns.append(col)
        else:
            actual_type = current_schema[col]
            if expected_type != actual_type:
                type_mismatch_columns.append((col, expected_type, actual_type))

    assert not missing_columns, f"Missing expected columns: {missing_columns}"
    assert not type_mismatch_columns, f"Datatype mismatch columns: {type_mismatch_columns}"

# COMMAND ----------

try:
    test_expected_columns_exist_and_validate_types()
    print("✅ Schema Validation Test Passed!")
except AssertionError as ae:
    print(f"❌ Schema Validation Test Failed: {str(ae)}")
    raise  # Re-raise to fail the notebook
except Exception as e:
    print(f"❌ Unexpected error occurred: {str(e)}")
    raise


# COMMAND ----------

missing_columns = [col for col in expected_columns if col not in current_schema]
type_mismatch_columns = [(col, expected_columns[col], current_schema.get(col, "NOT_FOUND"))
                         for col in expected_columns
                         if col in current_schema and expected_columns[col] != current_schema[col]]

if missing_columns or type_mismatch_columns:
    if missing_columns:
        print(f"❌ Missing Columns:")
        for col in missing_columns:
            print(f"  - {col}")
    if type_mismatch_columns:
        print(f"❌ Datatype mismatches:")
        for col, expected, actual in type_mismatch_columns:
            print(f"  - {col}: expected {expected}, found {actual}")
    raise Exception("Schema validation failed. See details above.")
else:
    print("✅ All columns and datatypes matched successfully!")

# COMMAND ----------

# COMMAND ----------
import json

# COMMAND ----------



# # COMMAND ----------
# # Accept inputs
# dbutils.widgets.text("schema_name", "")
# dbutils.widgets.text("table_name", "")
# dbutils.widgets.text("expected_columns", "")

# schema_name = dbutils.widgets.get("schema_name")
# table_name = dbutils.widgets.get("table_name")
# expected_columns_raw = dbutils.widgets.get("expected_columns")

# full_table_name = f"{schema_name}.{table_name}"

# Parse expected columns
expected_columns = {}
for item in expected_columns_raw.split(","):
    if ":" in item:
        colname, datatype = item.strip().split(":")
        expected_columns[colname.strip()] = datatype.strip().lower()
    else:
        raise ValueError(f"Invalid expected column format: '{item}'. Expected 'column:datatype'.")

# COMMAND ----------
# Load table schema
try:
    df = spark.table(full_table_name)
    current_schema = {field.name: field.dataType.simpleString().lower() for field in df.schema.fields}
except Exception as e:
    result = {
        "status": "FAIL",
        "message": f"Error loading table '{full_table_name}': {str(e)}"
    }
    print(json.dumps(result, indent=2))
    dbutils.notebook.exit(json.dumps(result))

# COMMAND ----------
# Validation logic
missing_columns = []
datatype_mismatches = []

for col, expected_type in expected_columns.items():
    if col not in current_schema:
        missing_columns.append(col)
    else:
        actual_type = current_schema[col]
        if expected_type != actual_type:
            datatype_mismatches.append((col, expected_type, actual_type))

# COMMAND ----------
# Build result
if not missing_columns and not datatype_mismatches:
    result = {
        "status": "PASS",
        "message": "✅ All expected columns and datatypes match successfully."
    }
else:
    failure_message = ""
    if missing_columns:
        failure_message += f"❌ Missing columns: {missing_columns}. "
    if datatype_mismatches:
        mismatch_details = "; ".join([f"{col} (expected {exp}, found {act})" for col, exp, act in datatype_mismatches])
        failure_message += f"❌ Datatype mismatches: {mismatch_details}. "

    result = {
        "status": "FAIL",
        "message": failure_message
    }

# COMMAND ----------
# Final output
print(json.dumps(result, indent=2))
dbutils.notebook.exit(json.dumps(result))
