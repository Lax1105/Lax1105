# Databricks notebook source
pip install pytest

# COMMAND ----------

# COMMAND ----------
import pytest
import json

# COMMAND ----------

# COMMAND ----------
# Accept Widgets
dbutils.widgets.text("schema_name", "")
dbutils.widgets.text("table_name", "")
dbutils.widgets.text("expected_columns", "")

# COMMAND ----------

# Accept input parameters
dbutils.widgets.text("schema_name", "enriched")
dbutils.widgets.text("table_name", "crm_phonecall")
dbutils.widgets.text("expected_columns", "statecodeName:string")  # Format: col1:datatype(length),col2:datatype(length)

# COMMAND ----------

schema_name = dbutils.widgets.get("schema_name")
table_name = dbutils.widgets.get("table_name")
expected_columns_raw = dbutils.widgets.get("expected_columns")

# COMMAND ----------

full_table_name = f"{schema_name}.{table_name}"

# COMMAND ----------

expected_columns = {}
for item in expected_columns_raw.split(","):
    if ":" in item:
        colname, datatype = item.strip().split(":")
        expected_columns[colname.strip()] = datatype.strip().lower()
    else:
        raise ValueError(f"Invalid expected column format: '{item}'. Expected 'column:datatype'.")

# COMMAND ----------

class SchemaValidator:
    def __init__(self, table_name, expected_columns):
        self.table_name = table_name
        self.expected_columns = expected_columns
        self.result = {
            "status": "PASS",
            "message": ""
        }

    def load_table_schema(self):
        try:
            df = spark.table(self.table_name)
            self.current_schema = {field.name: field.dataType.simpleString().lower() for field in df.schema.fields}
        except Exception as e:
            self.result["status"] = "FAIL"
            self.result["message"] = f"❌ Failed to load table '{self.table_name}': {str(e)}"
            return False
        return True

    def validate_schema(self):
        missing_columns = []
        datatype_mismatches = []

        for col, expected_type in self.expected_columns.items():
            if col not in self.current_schema:
                missing_columns.append(col)
            else:
                actual_type = self.current_schema[col]
                if expected_type != actual_type:
                    datatype_mismatches.append((col, expected_type, actual_type))

        if missing_columns or datatype_mismatches:
            failure_message = "❌ Schema Validation Test Failed:\n"
            if missing_columns:
                failure_message += f"   - Missing Columns: {missing_columns}\n"
            if datatype_mismatches:
                mismatch_details = "\n".join(
                    [f"     > {col}: expected '{exp}', found '{act}'" for col, exp, act in datatype_mismatches]
                )
                failure_message += f"   - Datatype Mismatches:\n{mismatch_details}"
            self.result["status"] = "FAIL"
            self.result["message"] = failure_message
        else:
            self.result["status"] = "PASS"
            self.result["message"] = "✅ Schema Validation Test Passed: All expected columns and datatypes matched."

        return self.result

# COMMAND ----------

validator = SchemaValidator(full_table_name, expected_columns)

# COMMAND ----------

@pytest.mark.schema_validation
def test_schema_validation():
    loaded = validator.load_table_schema()
    if loaded:
        result = validator.validate_schema()
        print(json.dumps(result, indent=2))
    else:
        print(json.dumps(validator.result, indent=2))

test_schema_validation()  # Manually call it because notebook needs it
dbutils.notebook.exit(json.dumps(validator.result))
